

Download the game contents first by opening command prompt and typing bash ./install.bash

This will download the zip file which is pretty large ~ 11.4 GB 

Unzip the file in the "UnrealTournament_Clear_Linux" folder 

If using Gnome right click the "RunGame" and select "Run as a Program"
Else open up terminal and type bash ./RunGame

KNOWN ISSUES
Besides the obvious, there seems to be an issue with logging into the Epic Community servers.. not sure why but for now the game is only playable offline.  Still fun though ;-)

If you need some help you can find me usually in the clear linux irc channel.

Thanks,
ablyss


