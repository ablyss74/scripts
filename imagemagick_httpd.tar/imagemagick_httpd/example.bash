main() {
	echo "<html><head></head><body style=\"background-color: rgb(150, 50, 5);\">"
	print1() {
		magick -size 150x75 canvas:none -font "/usr/share/fonts/X11/Type1/c0648bt_.pfb" -pointsize 75   -draw "text 25,60 \'$var\'" 
		-channel RGBA -blur 0x6 -fill darkred -stroke black   -draw "text 30,55 \'$var\'" -trim +repage /tmp/$var.png
		r=$(openssl enc -base64 -in /tmp/$var.png)
	}
	print2() {
		echo "<img border=\"0\" width=\"75\" height=\"75\" src=\"data:image/gif;base64,${r} \">"
	}

	for var in {A..Z}
		do 
			print1
			print2
			
		done
	echo "<br>"
}
main


