main() {

	print1() {
		shuf1=$(shuf -i 0-250 -n 1)
		shuf2=$(shuf -i 0-250 -n 1)
		shuf3=$(shuf -i 0-250 -n 1)
		echo "<html><head></head><body style=\"background-color: rgb(${shuf1}, ${shuf2}, ${shuf3});\">"
		magick -size 150x75 canvas:none -font "/usr/share/fonts/X11/Type1/c0648bt_.pfb" -pointsize 75   -draw "text 25,60 \'$var\'" \
		-channel RGBA -blur 0x6 -fill darkred -stroke black   -draw "text 30,55 \'$var\'" -trim +repage /tmp/$var.png
		r=$(openssl enc -base64 -in /tmp/$var.png)
		echo "<img border=\"0\" width=\"75\" height=\"75\" src=\"data:image/gif;base64,${r} \">"
	}


	for var in {A..Z} "-" {a..z} "-" {0..9} \\n \\n\\n \\n\\n \\n\\n \\n\\n \\n\\n \\n \\n \\n\\n . \\n\\n . . \\n\\n . . . \\n\\n . . . . ":-)" 
		do 
			print1
		
		done
echo "</body></html>"
}
main


