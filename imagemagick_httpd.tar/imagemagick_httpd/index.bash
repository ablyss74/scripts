#!/usr/bin/env bash
###############################################################
#          Example httpd server page with ImageMagick 
#
#       To run, open terminal and type:
#	bash ./index.bash
#	Open a modern web browser to http://localhost:1234
#	Try out different fonts
#
###############################################################

# List on non priviledged port 1234, do stuff on localhost / 127.0.0.1
socat -v -v TCP-LISTEN:1234,crlf,reuseaddr,fork SYSTEM:"
echo HTTP/1.0 200
echo Content-Type\: text/html; echo
#
. ./example.bash
"

